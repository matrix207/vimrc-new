vim-cucumber-align-pipes
========================

What it does: Aligns pipes when you are editing Cucumber tables.

Makes [that](https://gist.github.com/287147) popular gist a VIM plugin.

**Warning**: It is dependant on [Tabularize](https://github.com/godlygeek/tabular)
